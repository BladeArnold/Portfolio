(QSORT)
// int QSORT(int *begin, int *end) {
    $pushFrame 2 2
    =QSORT.begin 0
    =QSORT.end 1
//   int sz ;
    =QSORT.sz 0
//   int *split ;
    =QSORT.split 1
    $setPTR 
//   sz = end-begin ;
    $getArgument QSORT.end
    $pushD
    $getArgument QSORT.begin
    $pushD
    $sub
    $popAD
    $setLocal QSORT.pivots
//   if(sz < 2)
        $getLocal QSORT.sz
        $pushD
        @2
        $pushD
        $lt
        $popAD
//     return sz ;
        $getLocal QSORT.sz
        $setArgument 0
        $popFrame 2 2
        $return
//   split = PARTITION(begin,end) ;
        $getLocal QSORT.split
        $pushD
        $getArgument QSORT.begin
        $pushD
        $getArgument QSORT.end
        $pushD
        $popAD
        $popAD
        $setLocal QSORT.split
//   QSORT(begin,split) ;
        $getLocal QSORT.split
        $pushD
        $getArgument QSORT.begin
        $pushD
//   QSORT(split,end) ;
        $getLocal QSORT.split
        $pushD
        $getArgument QSORT.end
        $pushD
//   return sz ;
$getLocal QSORT.sz
$setArgument 0
$popFrame 2 2
$return
// } 

(PARTITION)
// Lomuto Partitioning Scheme
// int *PARTITION(int *begin, int *end) {
    $pushFrame 2 3
    =PARTITION.begin 0
    =PARTITION.end 1
//   int *i, *j, pivot ;
   =PARTITION.i 0
    $setPTR i
    =PARTITION.j 1
    $setPTR 
    =PARTITION.pivot 2
//   pivot = *(end-1);
    $getArgument PARTITION.end
    $pushD
    $setLocal PARTITION.pivot
    $pushD
    $sub
    $getPTR
    $popAD
    $setLocal PARTITION.pivots
//   i = begin - 1
    $getArgument PARTITION.begin
    $pushD
    $setLocal PARTITION.i
    $pushD
    $sub
    $popAD
    $setLocal PARTITION.i

//   for(j=begin;j<end;j++) {
    $getArgument PARTITION.begin
    $setLocal PARTITION.j
    (PARTITION.LOOP1)
    $getLocal PARTITION.j
    $pushD
    $getArgument PARTITION.end
    $pushD
    $lt
    $popAD
    @PARTITION.LOOP1EXIT
    D;JEQ
//     if(*j <= pivot) {
        $getLocal PARTITION.pivot
        $pushD
        $getLocal PARTITION.j
        $pushD
        $getPTR
        $lt
        $eq
        $popAD
        $setLocal PARTITION.pivot
//        i = i + 1
        $getLocal PARTITION.i
        @PARTITION.LOOP1
        0;JMP
        (PARTITION.LOOP1EXIT)
//        swap(*i,*j) ;
        $getLocal PARTITION.i
        $pushD
        $setPTR
        $getLocal PARTITION.j
        $pushD
        $setPTR
        $popAD
        $setLocal PARTITION.j
        $setLocal PARTITION.i
//     }
//   }
//   return i ;
$getLocal PARTITION.i
$setArgument 0
$popFrame 2 3 
$return
// }

