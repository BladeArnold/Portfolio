def greetUser(firstname, lastname, middlename):

    print("Hello!")
    firstname = input("Welcome to the program ", firstname)
    middlename = input("Now your middle name ", middlename)
    lastname = input("Finally your last name ", lastname)
    
    print("Glad to have you!", firstname, " ", middlename, " ", lastname)